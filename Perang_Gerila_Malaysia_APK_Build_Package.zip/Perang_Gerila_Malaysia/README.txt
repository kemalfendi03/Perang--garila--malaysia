PERANG GERILA MALAYSIA: MISI RAHSIA

Status: Projek sumber Godot 4 + fail konfigurasi untuk binaan APK melalui GitHub Actions.
Penting: Ini masih BUKAN APK. Persekitaran ini tidak mempunyai Godot, Android SDK, atau akses internet untuk membina dan menguji APK secara terus.

Prototaip yang dirancang dalam kod:
- Persekitaran 3D hutan tropika dan pos kawalan
- Askar pemain dengan kamera orang ketiga
- Pergerakan dan tembakan menggunakan raycast
- 6 musuh AI mengejar dan menyerang pemain
- Sistem nyawa dan mesej misi selesai
- Kawalan sentuh asas

CARA CUBA BINA APK TANPA KOMPUTER SENDIRI:
1. Muat naik semua fail dalam folder projek ini ke repositori GitHub baharu menggunakan pelayar telefon.
2. Pastikan fail .github/workflows/build-android.yml dan export_presets.cfg turut dimuat naik.
3. Buka tab Actions dalam repositori GitHub dan jalankan workflow "Build Android APK" jika ia belum berjalan automatik.
4. Jika binaan berjaya, buka run workflow yang berjaya dan muat turun artifact bernama Perang-Gerila-Malaysia-APK. Ekstrak ZIP artifact untuk mendapatkan APK.

Nota: Workflow binaan awan disediakan tetapi belum dapat diuji dari persekitaran ini. Jika binaan gagal, log GitHub Actions diperlukan untuk membaiki ralat. Ini prototaip asas; grafik model sebenar, animasi, audio, kempen berbilang misi dan ujian pada telefon masih belum lengkap.
