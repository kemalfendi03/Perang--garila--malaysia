extends CharacterBody3D

var health := 100
var speed := 6.5
var gravity := 18.0
var fire_cooldown := 0.0
var camera_pivot: Node3D
var camera: Camera3D
var gun_tip: Marker3D
var touch_move := Vector2.ZERO

func _ready() -> void:
    var capsule := CapsuleMesh.new()
    capsule.radius = 0.42
    capsule.height = 1.8
    var body := MeshInstance3D.new()
    body.mesh = capsule
    var uniform := StandardMaterial3D.new()
    uniform.albedo_color = Color(0.24, 0.31, 0.19)
    body.material_override = uniform
    body.position.y = 0.9
    add_child(body)
    var col := CollisionShape3D.new()
    var shape := CapsuleShape3D.new()
    shape.radius = 0.42
    shape.height = 1.8
    col.shape = shape
    col.position.y = 0.9
    add_child(col)
    var head := MeshInstance3D.new()
    var hm := SphereMesh.new()
    hm.radius = 0.24
    hm.height = 0.48
    head.mesh = hm
    var skin := StandardMaterial3D.new()
    skin.albedo_color = Color(0.57, 0.4, 0.28)
    head.material_override = skin
    head.position.y = 1.9
    add_child(head)
    var gun := MeshInstance3D.new()
    var gm := BoxMesh.new()
    gm.size = Vector3(0.13, 0.13, 0.9)
    gun.mesh = gm
    var metal := StandardMaterial3D.new()
    metal.albedo_color = Color(0.08, 0.09, 0.08)
    gun.material_override = metal
    gun.position = Vector3(0.34, 1.25, -0.55)
    add_child(gun)
    gun_tip = Marker3D.new()
    gun_tip.position = Vector3(0.34, 1.25, -1.0)
    add_child(gun_tip)
    camera_pivot = Node3D.new()
    camera_pivot.position = Vector3(0, 1.5, 0)
    add_child(camera_pivot)
    camera = Camera3D.new()
    camera.position = Vector3(0, 2.2, 6.5)
    camera.rotation_degrees.x = -12
    camera.current = true
    camera_pivot.add_child(camera)
    Input.mouse_mode = Input.MOUSE_MODE_CAPTURED

func _unhandled_input(event: InputEvent) -> void:
    if event is InputEventMouseMotion and Input.mouse_mode == Input.MOUSE_MODE_CAPTURED:
        rotate_y(-event.relative.x * 0.0025)
        camera_pivot.rotate_x(-event.relative.y * 0.0018)
        camera_pivot.rotation.x = clamp(camera_pivot.rotation.x, -0.55, 0.35)
    if event is InputEventKey and event.pressed and event.keycode == KEY_ESCAPE:
        Input.mouse_mode = Input.MOUSE_MODE_VISIBLE

func _physics_process(delta: float) -> void:
    fire_cooldown = maxf(0.0, fire_cooldown - delta)
    var input_dir := Input.get_vector("move_left", "move_right", "move_forward", "move_back")
    if Input.is_action_pressed("touch_left"): input_dir.x -= 1
    if Input.is_action_pressed("touch_right"): input_dir.x += 1
    if Input.is_action_pressed("touch_forward"): input_dir.y -= 1
    if Input.is_action_pressed("touch_back"): input_dir.y += 1
    input_dir = input_dir.normalized()
    var direction := (global_transform.basis * Vector3(input_dir.x, 0, input_dir.y)).normalized()
    velocity.x = direction.x * speed
    velocity.z = direction.z * speed
    if not is_on_floor(): velocity.y -= gravity * delta
    else: velocity.y = 0
    move_and_slide()
    if Input.is_action_pressed("shoot") or Input.is_action_pressed("touch_shoot"):
        _shoot()

func _shoot() -> void:
    if fire_cooldown > 0.0: return
    fire_cooldown = 0.22
    var from := camera.global_position
    var to := from + (-camera.global_transform.basis.z * 65.0)
    var query := PhysicsRayQueryParameters3D.create(from, to)
    query.exclude = [self]
    var result := get_world_3d().direct_space_state.intersect_ray(query)
    if result and result.collider and result.collider.has_method("take_damage"):
        result.collider.take_damage(34)
    # Small muzzle flash effect.
    var flash := OmniLight3D.new()
    flash.light_color = Color(1.0, 0.65, 0.2)
    flash.light_energy = 1.8
    flash.omni_range = 3.0
    flash.position = gun_tip.position
    add_child(flash)
    get_tree().create_timer(0.06).timeout.connect(func(): if is_instance_valid(flash): flash.queue_free())

func take_damage(amount: int) -> void:
    health = maxi(0, health - amount)
    if health == 0:
        get_tree().reload_current_scene()
