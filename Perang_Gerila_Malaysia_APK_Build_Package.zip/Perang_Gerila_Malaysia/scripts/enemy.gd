extends CharacterBody3D
signal enemy_died

var player_ref: Node3D
var health := 100
var speed := 2.3
var attack_timer := 0.0
var gravity := 18.0
var alive := true

func _ready() -> void:
    var body := MeshInstance3D.new()
    var mesh := CapsuleMesh.new()
    mesh.radius = 0.43
    mesh.height = 1.8
    body.mesh = mesh
    var mat := StandardMaterial3D.new()
    mat.albedo_color = Color(0.36, 0.19, 0.14)
    body.material_override = mat
    body.position.y = 0.9
    add_child(body)
    var col := CollisionShape3D.new()
    var shape := CapsuleShape3D.new()
    shape.radius = 0.43
    shape.height = 1.8
    col.shape = shape
    col.position.y = 0.9
    add_child(col)
    var head := MeshInstance3D.new()
    var sphere := SphereMesh.new()
    sphere.radius = 0.23
    sphere.height = 0.46
    head.mesh = sphere
    var hm := StandardMaterial3D.new()
    hm.albedo_color = Color(0.48, 0.32, 0.23)
    head.material_override = hm
    head.position.y = 1.9
    add_child(head)

func _physics_process(delta: float) -> void:
    if not alive or not is_instance_valid(player_ref): return
    attack_timer = maxf(0.0, attack_timer - delta)
    var to_player: Vector3 = player_ref.global_position - global_position
    to_player.y = 0
    var distance := to_player.length()
    if distance > 2.2:
        var dir := to_player.normalized()
        velocity.x = dir.x * speed
        velocity.z = dir.z * speed
        look_at(Vector3(player_ref.global_position.x, global_position.y, player_ref.global_position.z), Vector3.UP)
    else:
        velocity.x = 0
        velocity.z = 0
        if attack_timer <= 0.0 and player_ref.has_method("take_damage"):
            player_ref.take_damage(8)
            attack_timer = 1.0
    if not is_on_floor(): velocity.y -= gravity * delta
    else: velocity.y = 0
    move_and_slide()

func take_damage(amount: int) -> void:
    if not alive: return
    health -= amount
    if health <= 0:
        alive = false
        enemy_died.emit()
        queue_free()
