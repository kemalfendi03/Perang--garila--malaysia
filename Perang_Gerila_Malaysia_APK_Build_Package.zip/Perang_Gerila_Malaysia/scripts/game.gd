extends Node3D

var player
var hud
var enemies_left := 6
var mission_complete := false
var ground_mat: StandardMaterial3D

func _ready() -> void:
    randomize()
    _make_world()
    _make_player()
    _spawn_enemies(6)
    _make_hud()

func _process(_delta: float) -> void:
    if is_instance_valid(hud):
        hud.get_node("Status").text = "MISI 01: BERSIHKAN KAWASAN  |  MUSUH: %d  |  NYAWA: %d" % [enemies_left, player.health]
    if enemies_left <= 0 and not mission_complete:
        mission_complete = true
        hud.get_node("Message").text = "MISI SELESAI! Kawasan berjaya dibersihkan."

func _make_world() -> void:
    var env := WorldEnvironment.new()
    var e := Environment.new()
    e.background_mode = Environment.BG_SKY
    e.ambient_light_source = Environment.AMBIENT_SOURCE_COLOR
    e.ambient_light_color = Color(0.55, 0.62, 0.48)
    e.ambient_light_energy = 0.8
    env.environment = e
    add_child(env)
    var sun := DirectionalLight3D.new()
    sun.rotation_degrees = Vector3(-48, -28, 0)
    sun.light_energy = 1.15
    add_child(sun)
    ground_mat = StandardMaterial3D.new()
    ground_mat.albedo_color = Color(0.18, 0.27, 0.15)
    var ground := MeshInstance3D.new()
    var plane := PlaneMesh.new()
    plane.size = Vector2(100, 100)
    ground.mesh = plane
    ground.material_override = ground_mat
    ground.position.y = -0.12
    add_child(ground)
    var body := StaticBody3D.new()
    body.name = "GroundCollision"
    var cs := CollisionShape3D.new()
    var box := BoxShape3D.new()
    box.size = Vector3(100, 0.2, 100)
    cs.shape = box
    body.add_child(cs)
    body.position.y = -0.12
    add_child(body)
    # Tropical trees made from simple meshes so the project has no external asset dependencies.
    for i in range(90):
        var x := randf_range(-44, 44)
        var z := randf_range(-44, 44)
        if Vector2(x, z).length() < 7.0:
            continue
        _make_tree(Vector3(x, 0, z))
    _make_outpost()

func _make_tree(pos: Vector3) -> void:
    var tree := Node3D.new()
    tree.position = pos
    add_child(tree)
    var trunk := MeshInstance3D.new()
    var cyl := CylinderMesh.new()
    cyl.top_radius = 0.22
    cyl.bottom_radius = 0.34
    cyl.height = randf_range(3.0, 5.0)
    trunk.mesh = cyl
    var bark := StandardMaterial3D.new()
    bark.albedo_color = Color(0.25, 0.17, 0.1)
    trunk.material_override = bark
    trunk.position.y = cyl.height / 2.0
    tree.add_child(trunk)
    var crown := MeshInstance3D.new()
    var sphere := SphereMesh.new()
    sphere.radius = randf_range(1.2, 1.8)
    sphere.height = sphere.radius * 1.8
    crown.mesh = sphere
    var leaves := StandardMaterial3D.new()
    leaves.albedo_color = Color(randf_range(0.08,0.16), randf_range(0.22,0.35), randf_range(0.08,0.14))
    crown.material_override = leaves
    crown.position.y = cyl.height + 0.8
    tree.add_child(crown)

func _make_outpost() -> void:
    var mat := StandardMaterial3D.new()
    mat.albedo_color = Color(0.35, 0.31, 0.22)
    for p in [Vector3(12, 1, -17), Vector3(16, 1, -17), Vector3(12, 1, -13), Vector3(16, 1, -13)]:
        var block := MeshInstance3D.new()
        var mesh := BoxMesh.new()
        mesh.size = Vector3(3.5, 2, 3.5)
        block.mesh = mesh
        block.material_override = mat
        block.position = p
        add_child(block)

func _make_player() -> void:
    player = CharacterBody3D.new()
    player.name = "PlayerSoldier"
    player.set_script(load("res://scripts/player.gd"))
    player.position = Vector3(0, 1, 8)
    add_child(player)

func _spawn_enemies(amount: int) -> void:
    for i in range(amount):
        var enemy := CharacterBody3D.new()
        enemy.name = "Enemy_%02d" % i
        enemy.set_script(load("res://scripts/enemy.gd"))
        enemy.position = Vector3(randf_range(-19, 19), 1, randf_range(-22, -8))
        enemy.player_ref = player
        enemy.enemy_died.connect(_on_enemy_died)
        add_child(enemy)

func _on_enemy_died() -> void:
    enemies_left = maxi(0, enemies_left - 1)

func _make_hud() -> void:
    hud = CanvasLayer.new()
    hud.name = "HUD"
    add_child(hud)
    var status := Label.new()
    status.name = "Status"
    status.position = Vector2(18, 14)
    status.add_theme_font_size_override("font_size", 20)
    status.add_theme_color_override("font_color", Color.WHITE)
    hud.add_child(status)
    var cross := Label.new()
    cross.text = "+"
    cross.set_anchors_and_offsets_preset(Control.PRESET_CENTER)
    cross.position = Vector2(-8, -18)
    cross.add_theme_font_size_override("font_size", 30)
    cross.add_theme_color_override("font_color", Color.WHITE)
    hud.add_child(cross)
    var msg := Label.new()
    msg.name = "Message"
    msg.position = Vector2(18, 48)
    msg.add_theme_font_size_override("font_size", 22)
    msg.add_theme_color_override("font_color", Color(1, 0.88, 0.45))
    hud.add_child(msg)
    var help := Label.new()
    help.text = "WASD / anak panah: bergerak   |   Klik kiri: tembak   |   Serang musuh dari dekat atau jauh"
    help.position = Vector2(18, 680)
    help.add_theme_font_size_override("font_size", 15)
    help.add_theme_color_override("font_color", Color.WHITE)
    hud.add_child(help)
    # Basic on-screen controls for touch devices.
    _touch_button("◀", Vector2(34, 555), Vector2(64,64), "left")
    _touch_button("▶", Vector2(162, 555), Vector2(64,64), "right")
    _touch_button("▲", Vector2(98, 490), Vector2(64,64), "forward")
    _touch_button("▼", Vector2(98, 620), Vector2(64,48), "back")
    _touch_button("TEMBAK", Vector2(1090, 565), Vector2(150,90), "shoot")

func _touch_button(label_text: String, pos: Vector2, size: Vector2, action: String) -> void:
    var b := TouchScreenButton.new()
    b.position = pos
    var shape := RectangleShape2D.new()
    shape.size = size
    b.shape = shape
    b.name = "Touch_" + action
    # TouchScreenButton uses action names for its pressed signal; movement is handled by virtual flags in player.gd.
    b.action = "touch_" + action
    var rect := ColorRect.new()
    rect.color = Color(0.1, 0.1, 0.1, 0.42)
    rect.size = size
    rect.mouse_filter = Control.MOUSE_FILTER_IGNORE
    # Add visible touch label independently.
    var holder := Control.new()
    holder.position = pos
    holder.size = size
    var bg := ColorRect.new()
    bg.color = Color(0.08,0.08,0.08,0.42)
    bg.size = size
    holder.add_child(bg)
    var l := Label.new()
    l.text = label_text
    l.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    l.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    l.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
    l.add_theme_font_size_override("font_size", 20 if action != "shoot" else 17)
    l.add_theme_color_override("font_color", Color.WHITE)
    holder.add_child(l)
    hud.add_child(holder)
    hud.add_child(b)
